package mg.androkabe.gpshydro

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.location.*
import android.os.Bundle
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class HydroPoint(val id:Long,val name:String,val category:String,val groupName:String,
 val lat:Double,val lon:Double,val alt:Double,val accuracy:Float,val note:String,val stamp:String)

class DbHelper(a:Activity):SQLiteOpenHelper(a,"gps_hydro.db",null,1){
 override fun onCreate(db:SQLiteDatabase){db.execSQL("CREATE TABLE points(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,category TEXT,grp TEXT,lat REAL,lon REAL,alt REAL,accuracy REAL,note TEXT,stamp TEXT)")}
 override fun onUpgrade(db:SQLiteDatabase,o:Int,n:Int){}
 fun insert(p:HydroPoint){
  val v=ContentValues().apply{put("name",p.name);put("category",p.category);put("grp",p.groupName);put("lat",p.lat);put("lon",p.lon);put("alt",p.alt);put("accuracy",p.accuracy);put("note",p.note);put("stamp",p.stamp)}
  writableDatabase.insert("points",null,v)
 }
 fun all():List<HydroPoint>{
  val out=mutableListOf<HydroPoint>()
  readableDatabase.rawQuery("SELECT * FROM points ORDER BY id DESC",null).use{c->while(c.moveToNext())out.add(HydroPoint(c.getLong(0),c.getString(1)?: "",c.getString(2)?: "",c.getString(3)?: "",c.getDouble(4),c.getDouble(5),c.getDouble(6),c.getFloat(7),c.getString(8)?: "",c.getString(9)?: ""))}
  return out
 }
}

class MainActivity:Activity(){
 private lateinit var db:DbHelper
 private lateinit var loc:LocationManager
 private var latest:Location?=null
 private lateinit var status:TextView
 private lateinit var nameInput:EditText
 private lateinit var noteInput:EditText
 private lateinit var category:Spinner
 private lateinit var group:Spinner
 private lateinit var content:LinearLayout
 private var pendingExport:String?=null
 private val categories=listOf("Turbine","Alternateur","Centrale hydraulique","Barrage","Prise d'eau","Canal d'amenée","Chambre de mise en charge","Aspirateur","Vanne","Autre")

 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  Configuration.getInstance().userAgentValue=packageName
  db=DbHelper(this);loc=getSystemService(LOCATION_SERVICE) as LocationManager;showHome()
  if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
   ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),10)
  else requestLocation()
 }
 private fun root(title:String){
  val outer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,20,20,16);setBackgroundColor(0xFFF5F7F6.toInt())}
  outer.addView(TextView(this).apply{text=title;textSize=22f;setTextColor(0xFF145B49.toInt());setPadding(0,8,0,18)})
  content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  outer.addView(content,LinearLayout.LayoutParams(-1,0,1f));setContentView(outer)
 }
 private fun txt(s:String,size:Float=16f){content.addView(TextView(this).apply{text=s;textSize=size;setTextColor(0xFF26332F.toInt());setPadding(0,6,0,6)})}
 private fun btn(s:String,action:()->Unit){content.addView(Button(this).apply{text=s;setOnClickListener{action()}})}
 private fun field(h:String)=EditText(this).apply{hint=h;textSize=15f;content.addView(this)}
 private fun spin(items:List<String>)=Spinner(this).also{s->s.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,items);content.addView(s)}
 private fun showHome(){
  root("GPS HYDRO – ANDROKABE")
  txt("Fakana sy fitahirizana Point GPS\nCollecte des points GPS")
  btn("Nouveau point GPS / Point vaovao"){showNew()}
  btn("Carte des installations / Sarintany"){showMap()}
  btn("Historique / Tantara"){showHistory()}
  btn("Export CSV / Excel"){exportCsv()}
  btn("Export KML"){exportKml()}
  txt("GPS et données locales utilisables sans Internet.",13f)
 }
 private fun showNew(){
  root("Nouveau point / Point vaovao")
  nameInput=field("Nom du point / Anaran'ny toerana")
  category=spin(categories);group=spin(listOf("Groupe 01","Groupe 02","Installation générale"))
  noteInput=field("Description / Fanamarihana")
  status=TextView(this).apply{textSize=15f;setPadding(0,12,0,12)};content.addView(status);refreshStatus()
  btn("Actualiser GPS / Maka GPS"){requestLocation();refreshStatus()}
  btn("Enregistrer / Tehirizo"){savePoint()}
  btn("Retour"){showHome()}
 }
 private fun refreshStatus(){
  val l=latest
  status.text=if(l==null)"GPS tsy mbola azo. Alefaso ny Localisation ary mankanesa eny ivelany."
  else "Latitude: ${l.latitude}\nLongitude: ${l.longitude}\nAltitude: ${l.altitude} m\nPrécision: ${l.accuracy} m"
 }
 private fun requestLocation(){
  if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)return
  try{
   for(p in loc.getProviders(true))loc.getLastKnownLocation(p)?.let{if(latest==null||it.time>latest!!.time)latest=it}
   val provider=if(loc.isProviderEnabled(LocationManager.GPS_PROVIDER))LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
   loc.requestLocationUpdates(provider,1000L,0f,object:LocationListener{
    override fun onLocationChanged(location:Location){latest=location;if(::status.isInitialized)refreshStatus();loc.removeUpdates(this)}
    @Deprecated("Deprecated in Java") override fun onStatusChanged(p:String?,s:Int,e:Bundle?){}
    override fun onProviderEnabled(p:String){};override fun onProviderDisabled(p:String){}
   })
  }catch(_:Exception){}
 }
 private fun savePoint(){
  val l=latest;if(l==null){toast("GPS tsy mbola azo. Andramo indray.");requestLocation();return}
  val stamp=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.getDefault()).format(Date())
  db.insert(HydroPoint(0,nameInput.text.toString().ifBlank{"Point ${db.all().size+1}"},categories[category.selectedItemPosition],group.selectedItem.toString(),l.latitude,l.longitude,l.altitude,l.accuracy,noteInput.text.toString(),stamp))
  toast("Point voatahiry / Point enregistré");showHome()
 }
 private fun showHistory(){
  root("Historique / Tantara");val pts=db.all()
  if(pts.isEmpty())txt("Tsy mbola misy point voatahiry.")
  pts.forEach{txt("${it.id}. ${it.name} — ${it.category} (${it.groupName})\n${it.lat}, ${it.lon}\n${it.stamp}",14f)}
  btn("Retour"){showHome()}
 }
 private fun showMap(){
  root("Carte GPS / Sarintany")
  val map=MapView(this).apply{setTileSource(TileSourceFactory.MAPNIK);setMultiTouchControls(true);controller.setZoom(14.0)}
  val pts=db.all()
  if(pts.isNotEmpty()){
   map.controller.setCenter(GeoPoint(pts.first().lat,pts.first().lon))
   pts.forEach{p->val m=Marker(map);m.position=GeoPoint(p.lat,p.lon);m.title=p.name;m.snippet="${p.category} • ${p.groupName}\n${p.lat}, ${p.lon}";map.overlays.add(m)}
  }else txt("Tsy mbola misy point. Mila Internet ny sarintany raha tsy mbola nisy tiles voatahiry.")
  content.addView(map,LinearLayout.LayoutParams(-1,0,1f));btn("Retour"){map.onDetach();showHome()}
 }
 private fun exportCsv(){
  val pts=db.all();if(pts.isEmpty()){toast("Tsy misy point azo export-na");return}
  val head="ID;Nom;Equipement;Groupe;Latitude;Longitude;Altitude_m;Precision_m;Description;Date_heure\n"
  val body=pts.joinToString("\n"){p->listOf(p.id,p.name,p.category,p.groupName,p.lat,p.lon,p.alt,p.accuracy,p.note,p.stamp).joinToString(";"){v->"\"${v.toString().replace("\"","\"\"")}\""}}
  createFile("text/csv","GPS_HYDRO_Androkabe.csv",head+body)
 }
 private fun exportKml(){
  val pts=db.all();if(pts.isEmpty()){toast("Tsy misy point azo export-na");return}
  val marks=pts.joinToString("\n"){p->"<Placemark><name>${xml(p.name)}</name><description>${xml(p.category+" / "+p.groupName+" / "+p.note)}</description><Point><coordinates>${p.lon},${p.lat},${p.alt}</coordinates></Point></Placemark>"}
  createFile("application/vnd.google-earth.kml+xml","GPS_HYDRO_Androkabe.kml","<?xml version=\"1.0\"?><kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document><name>GPS HYDRO Androkabe</name>$marks</Document></kml>")
 }
 private fun xml(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;")
 private fun createFile(type:String,filename:String,data:String){
  pendingExport=data
  val i=android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(android.content.Intent.CATEGORY_OPENABLE);this.type=type;putExtra(android.content.Intent.EXTRA_TITLE,filename)}
  startActivityForResult(i,22)
 }
 @Deprecated("Deprecated in Java") override fun onActivityResult(r:Int,c:Int,d:android.content.Intent?){super.onActivityResult(r,c,d);if(r==22&&c==RESULT_OK)d?.data?.let{u->contentResolver.openOutputStream(u)?.bufferedWriter()?.use{it.write(pendingExport?:"")}};toast("Exportation terminée")}
 override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){super.onRequestPermissionsResult(r,p,g);if(r==10&&g.any{it==PackageManager.PERMISSION_GRANTED})requestLocation()}
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
