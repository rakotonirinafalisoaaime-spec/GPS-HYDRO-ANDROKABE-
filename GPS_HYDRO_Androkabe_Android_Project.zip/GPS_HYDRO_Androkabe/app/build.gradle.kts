plugins {
 id("com.android.application")
 id("org.jetbrains.kotlin.android")
}
android {
 namespace = "mg.androkabe.gpshydro"
 compileSdk = 35
 defaultConfig {
  applicationId = "mg.androkabe.gpshydro"
  minSdk = 23
  targetSdk = 35
  versionCode = 1
  versionName = "1.0"
 }
}
dependencies {
 implementation("androidx.core:core-ktx:1.15.0")
 implementation("org.osmdroid:osmdroid-android:6.1.20")
}
